package com.shayaristudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShayariStudioApp() }
    }
}

@Composable
fun ShayariStudioApp() {
    val categories = listOf("Love", "Attitude", "Brother", "Friendship", "Motivation", "Sad")
    var selected by remember { mutableStateOf("Love") }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(20.dp)
            ) {
                Text("Shayari Studio", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Status banao, style ke saath.", fontSize = 16.sp)
                Spacer(Modifier.height(20.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { category ->
                        FilterChip(
                            selected = selected == category,
                            onClick = { selected = category },
                            label = { Text(category) }
                        )
                    }
                }

                Spacer(Modifier.height(28.dp))

                Card(modifier = Modifier.fillMaxWidth().height(300.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            when (selected) {
                                "Love" -> "Mohabbat lafzon se nahi,
dil se mehsoos hoti hai ❤️"
                                "Attitude" -> "Khamoshi meri aadat hai,
kamzori nahi. 🔥"
                                "Brother" -> "Bhai saath ho to
har mushkil aasaan lagti hai. 🤝"
                                "Friendship" -> "Dosti wahi jo waqt ke saath
rang na badle. 🫶"
                                "Motivation" -> "Dheere chal raha hoon,
lekin ruk nahi raha. 🚀"
                                else -> "Kuch yaadein dil mein
hamesha zinda rehti hain."
                            },
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))

                Button(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Create Status") }

                Spacer(Modifier.height(10.dp))

                OutlinedButton(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Generate Shayari") }
            }
        }
    }
}
